#!/bin/bash
rm -rf .idea .gradle magisterapi.iml src/main/java/eu/magisterapp/magisterapi/Main.java
